package com.capgemini.jdbc.presentation;

import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;


import com.capgemini.jdbc.bean.Account;
import com.capgemini.jdbc.exception.BankException;
import com.capgemini.jdbc.service.BankService;
import com.capgemini.jdbc.service.BankServiceImpl;



public class MainUI {
	public static void main(String[] args) {
			BankService service=new BankServiceImpl();
		
		String continueChoice;
		boolean continueValue = false;

		Scanner scanner = null;
		do {

			System.out.println("****** Welcome To The Bank ******");
			System.out.println("1.Create The Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show The Balance");
			System.out.println("6.Print The Transaction");
			System.out.println("7. Exit");
			
			int choice = 0;
			boolean choiceFlag = false;
			do {
				System.out.println("Enter Input:");
				try {
					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					choiceFlag = true;
				    
					switch(choice) {
					case 1:{
						String firstName=null;
						String surName=null; 
						long mobile=0;
						System.out.println("***Creating The Account***");
						boolean fnameFlag=false;
						do {
					System.out.println("Enter your first Name:");
					scanner = new Scanner(System.in);
				    firstName=scanner.next();
				    fnameFlag=true;
				    if(!service.isNameValid(firstName)) {
				    	try {
							throw new BankException("The Name should start with capital letter and name should be minimum of 5 characters");
						} catch (BankException e) {
							fnameFlag=false;
							System.out.println(e.getMessage());
						}
				    }
						}while(!fnameFlag);
						
						
						boolean sNameFlag=false;
						do {
					System.out.println("Enter your Surname:");
					scanner = new Scanner(System.in);
				    surName=scanner.next();
				    sNameFlag=true;
				    if(!service.isNameValid(surName)) {
				    	try {
							throw new BankException("The Name should start with capital letter and name should be minimum of 5 characters");
						} catch (BankException e) {
							sNameFlag=false;
							System.out.println(e.getMessage());
						}
				    }
						}while(!sNameFlag);
						boolean phoneFlag=false;
						do {
				    System.out.println("Enter the Mobile number:");
				    scanner = new Scanner(System.in);
				     mobile=scanner.nextLong();
				    phoneFlag=true;
				    if(!service.isPhoneValid(mobile)) {
				    	try {
							throw new BankException("The mobile number should start with 7,8 or 9 and should have only 10 digits and not caharacters");
						} catch (BankException e) {
							phoneFlag=false;
							System.out.println(e.getMessage());
						}
				    }
						}while(!phoneFlag);
						
						long balance=0;
						 boolean balFlag=false;
						 do {
				    System.out.println("Enter the balance:");
				    scanner = new Scanner(System.in);
				   balance=scanner.nextLong();
				   balFlag=true;
				   
				   try {
					service.isBalanceValid(balance);
					
				} catch (BankException e) {
					balFlag=false;
					System.out.println(e.getMessage());
				}
				    }while(!balFlag);
				  
				    	
							System.out.println("enter the gender:");
							scanner = new Scanner(System.in);
							String gender=scanner.next();
							/*Account account=new Account(0, name, mobile, gender, balance);*/
							Account account=new Account(0, firstName, surName, mobile, gender, balance);
							long accountNo=service.addAccountDetails(account);
							System.out.println("Account created successfully with account number="+accountNo);
							
						
						
					}break;
					case 2:
					{
						System.out.println("Enter your account no:");
						scanner = new Scanner(System.in);
						long accountNo=scanner.nextLong();
						System.out.println("Enter the deposit amount:");
						scanner = new Scanner(System.in);
						long depositAmount=scanner.nextLong();
						long deposit=service.addDeposit(accountNo, depositAmount);
						System.out.println("The total balance in your account after deposting "+depositAmount+"is "+deposit);
						
					}break;
					case 3:{
						System.out.println("Enter the account number");
						scanner = new Scanner(System.in);
						long accountNo=scanner.nextLong();
						System.out.println("Enter the amount to be withdrawn:");
						scanner = new Scanner(System.in);
						long withdrawAmount=scanner.nextLong();
						long remaining=service.afterWithdraw(accountNo, withdrawAmount);
						System.out.println("remaining balance after withdrwaing "+withdrawAmount+" is"+remaining);
						
		
					}break;
					case 4:{
						System.out.println("Enter your account Number:");
						scanner = new Scanner(System.in);
						long accountNo=scanner.nextLong();
						System.out.println("Enter the account Number to which the fund is to be transferred:");
						long accountNo2=scanner.nextLong();
						scanner = new Scanner(System.in);
						System.out.println("Enter the amount to be transferred:");
						scanner = new Scanner(System.in);
						long fundTransferAmount=scanner.nextLong();
						long remainingBalance=service.fundTransfer(accountNo, fundTransferAmount);
						System.out.println("The balance remaining in your account after fund transfer of "+fundTransferAmount+"is "+remainingBalance);
						
						
					}break;
					case 5:{
						System.out.println("Enter the account number:");
						scanner = new Scanner(System.in);
						long accountNo=scanner.nextLong();
						long totalBalance=service.showBalance(accountNo);
						System.out.println("The Balance in Your Account is:"+totalBalance);
						
						
					}break;
					
					case 6:
					{
						
						
					}break;
					case 7:{
						System.out.println("Thank you");
						System.exit(0);
					}break;
					}
	} catch (InputMismatchException exception) {
		choiceFlag = false;
		System.err.println("input should contain only digits");
	}
} while (!choiceFlag);

		do {
			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();
			if (continueChoice.equalsIgnoreCase("yes")) {
				continueValue = true;
				break;
			} else if (continueChoice.equalsIgnoreCase("no")) {
				System.out.println("thank you");
				continueValue = false;
				break;
			} else {
				System.out.println("enter yes or no");
				continueValue = false;
				continue;
			}
		} while (!continueValue);

	} while (continueValue);
	scanner.close();
}
	



	}


