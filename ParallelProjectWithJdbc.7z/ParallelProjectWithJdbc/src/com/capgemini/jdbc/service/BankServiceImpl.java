package com.capgemini.jdbc.service;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.jdbc.bean.Account;
import com.capgemini.jdbc.dao.BankDao;
import com.capgemini.jdbc.dao.BankDaoImpl;
import com.capgemini.jdbc.exception.BankException;

public class BankServiceImpl implements BankService {
	 int row=-1;
	 BankDao dao=new BankDaoImpl();

	@Override
	public long addAccountDetails(Account account) {
		return dao.addAccount(account);
		   
	}

	@Override
	public long addDeposit(long accountNo, long depositAmount) {
		
		return dao.addDeposit(accountNo, depositAmount);
	}

	@Override
	public long afterWithdraw(long accountNo, long withdrawAmount) {
		
		return dao.afterWithdraw(accountNo, withdrawAmount);
	}

	@Override
	public long showBalance(long accountNo) {
		
		return dao.showBalance(accountNo);
	}

	@Override
	public long fundTransfer(long accountNo, long fundTransferAmount) {
		
		return dao.fundTransfer(accountNo, fundTransferAmount);
	}

	@Override
	public boolean isNameValid(String name) {
		Pattern nameptn=Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match=nameptn.matcher(name);
		if(match.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean isPhoneValid(long phone) {
		String mobile=String.valueOf(phone);
		Pattern mobileptn=Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match=mobileptn.matcher(mobile);
		if(match.matches()) {
			return true;
		}
		return false;
	}

	@Override
	public boolean isBalanceValid(long balance) throws BankException {
		boolean balanceFlag=false;
		if(balance<1000) {
			throw new BankException("Sorry, the minimum balance in the account should be 1000 and not less than that");
		}else {
			balanceFlag=true;
		}
		return balanceFlag;
	}

}
