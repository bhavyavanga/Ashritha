package com.capgemini.jdbc.service;


import com.capgemini.jdbc.bean.Account;
import com.capgemini.jdbc.exception.BankException;

public interface BankService {
	long addAccountDetails(Account account);
	long addDeposit(long accountNo,long depositAmount);
	long afterWithdraw(long accountNo, long withdrawAmount);
	public long showBalance(long accountNo);
	public long fundTransfer(long accountNo, long fundTransferAmount);
	 public boolean isNameValid(String name);
	 public boolean isPhoneValid(long phone);
	 public boolean isBalanceValid(long balance) throws BankException;

}
