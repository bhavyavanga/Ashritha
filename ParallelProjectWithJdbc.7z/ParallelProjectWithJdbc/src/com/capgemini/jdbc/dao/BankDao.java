package com.capgemini.jdbc.dao;

import com.capgemini.jdbc.bean.Account;

public interface BankDao {
	public long addAccount(Account account);
	public long addDeposit( long accountNo , long depositAmount);
	public long afterWithdraw(long accountNo, long withdrawAmount);
	public long showBalance(long accountNo);
	public long fundTransfer(long accountNo, long fundTransferAmount);

}
