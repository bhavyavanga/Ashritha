package com.capgemini.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.jdbc.bean.Account;

import com.capgemini.jdbc.connection.DBConnection;

public class BankDaoImpl implements BankDao {
	Connection connection=null;
	PreparedStatement statement=null;
	ResultSet resultSet=null;
	boolean status=false;
	long row=-1;

	

	@Override
	public long addAccount(Account account) {
		int accountNo=0;
		try(Connection connection=DBConnection.getConnection();){
			statement=connection.prepareStatement("select accbankseq.NEXTVAL from dual");
			resultSet=statement.executeQuery();
			if(resultSet.next())
				accountNo=resultSet.getInt(1);
			statement=connection.prepareStatement("insert into account values(?,?,?,?,?,?)");
			statement.setInt(1, accountNo);
			statement.setString(2, account.getFirstName());
			statement.setString(3, account.getSurName());
			statement.setLong(4, account.getMobileNumber());
			statement.setString(5, account.getGender());
			statement.setLong(6,account.getBalance());
			
			row=statement.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return accountNo;
	}



	@Override
	public long addDeposit(long accountNo, long depositAmount) {
Connection connection=DBConnection.getConnection();
long balance=0,balance1=0;
	 try {
         statement=connection.prepareStatement("select balance from account where accountNo=?");
         statement.setLong(1, accountNo);
         ResultSet rs=statement.executeQuery();
         while(rs.next())
         {               
             balance=rs.getLong(1);
             statement=connection.prepareStatement("update account set balance=? where accountNo=?");
             balance1=balance+depositAmount;
             statement.setLong(1, balance1);
             statement.setLong(2, accountNo);
          statement.executeUpdate();
//             if(i>0)
//             {
//                 ps=con.prepareStatement("Insert into transactions values(?,?)");
//                 ps.setInt(1, accountNo);
//                 ps.setString(2, "Amount "+amount+"deposited on "+ dateAndTime());
//                 ps.executeUpdate();
                 
         }
//         }
     } catch (SQLException e) {
       e.printStackTrace();
    }
 return balance1;
//     return -1;
	}



	@Override
	public long afterWithdraw(long accountNo, long withdrawAmount) {
		Connection connection=DBConnection.getConnection();
		long balance=0,balance1=0;
			 try {
		         statement=connection.prepareStatement("select balance from account where accountNo=?");
		         statement.setLong(1, accountNo);
		         ResultSet rs=statement.executeQuery();
		         while(rs.next())
		         {               
		             balance=rs.getLong(1);
		             statement=connection.prepareStatement("update account set balance=? where accountNo=?");
		             balance1=balance-withdrawAmount;
		             statement.setLong(1, balance1);
		             statement.setLong(2, accountNo);
		          statement.executeUpdate();
//		             if(i>0)
//		             {
//		                 ps=con.prepareStatement("Insert into transactions values(?,?)");
//		                 ps.setInt(1, accountNo);
//		                 ps.setString(2, "Amount "+amount+"deposited on "+ dateAndTime());
//		                 ps.executeUpdate();
		                 
		         }
//		         }
		     } catch (SQLException e) {
		       e.printStackTrace();
		    }
		 return balance1;
	}



	@Override
	public long showBalance(long accountNo) {
		Connection connection=DBConnection.getConnection();
		long balance=0;
			 try {
		         statement=connection.prepareStatement("select balance from account where accountNo=?");
		         statement.setLong(1, accountNo);
		         ResultSet rs=statement.executeQuery();
		         while(rs.next())
		         {               
		             balance=rs.getLong(1);
		         }
//		         }
		     } catch (SQLException e) {
		       e.printStackTrace();
		    }
		 return balance;
	}



	@Override
	public long fundTransfer(long accountNo, long fundTransferAmount) {
		Connection connection=DBConnection.getConnection();
		long balance=0,balanceRemain=0;
			 try {
		         statement=connection.prepareStatement("select balance from account where accountNo=?");
		         statement.setLong(1, accountNo);
		         ResultSet rs=statement.executeQuery();
		         while(rs.next())
		         {               
		             balance=rs.getLong(1);
		             statement=connection.prepareStatement("update account set balance=? where accountNo=?");
		             balanceRemain=balance-fundTransferAmount;
		             statement.setLong(1, balanceRemain);
		             statement.setLong(2, accountNo);
		          statement.executeUpdate();
//		             if(i>0)
//		             {
//		                 ps=con.prepareStatement("Insert into transactions values(?,?)");
//		                 ps.setInt(1, accountNo);
//		                 ps.setString(2, "Amount "+amount+"deposited on "+ dateAndTime());
//		                 ps.executeUpdate();
		                 
		         }
//		         }
		     } catch (SQLException e) {
		       e.printStackTrace();
		    }
		 return balanceRemain;
	}



	
}
