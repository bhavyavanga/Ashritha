package com.capgemini.java.dao;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public class BankDaoImpl implements BankDAO {
	public static Map<Long, BankAccount> accountMap=new HashMap<>();
    static  Map<Integer, Transaction> transactionDetails=new HashMap<>();
	@Override
	//public long addAccountDetails(BankAccount account) {
//		double Number=Math.random()*1000000000;
//		int accountId=(int) Number;
//		
//		accountMap.put(accountId, account);
		//accountMap.put(account.getAccountNo(), account);
		//return account.getAccountNo();
	//}
	public Map<Long, BankAccount> accountDetails(BankAccount account){
		accountMap.put(account.getAccountNo(), account);
	
	return accountMap;	
	}

	@Override
	public int addTransactionDetails(Transaction transaction) {
		transactionDetails.put(transaction.getTransactionId(), transaction);
		return transaction.getTransactionId();
	}

//	@Override
//	public Map<Integer, BankAccount> getAllAccountDetails() {
//		
//		return null;
//	}
//
//	@Override
//	public Map<Integer, Transaction> getAllTransactionDetails() {
//		
//		return null;
//	}

	@Override
	public long addDeposit(long accountNo, long depositedAmount) {
		long depositedBalance=0;
		Iterator<BankAccount> iterator=accountMap.values().iterator();
		while(iterator.hasNext()) {
			BankAccount acc=iterator.next();
			long accNo=acc.getAccountNo();
			double balance=acc.getBalance();
			if(accNo==accountNo) {
				depositedBalance=(long)(balance+depositedAmount);
				acc.setBalance(depositedBalance);
		}
		}
//		System.out.println("dffd");
		return depositedBalance;
	}
	
	public long afterWithdraw(long accountNo, long withdrawAmount) {
		long remainingBalance=0;
		Iterator<BankAccount> iterator=accountMap.values().iterator();
		while(iterator.hasNext()) {
			BankAccount acc=iterator.next();
			long accNo=acc.getAccountNo();
			double balance=acc.getBalance();
			
			if(accNo==accountNo) {
				if(withdrawAmount>balance) {
					remainingBalance=(long) balance;
					System.out.println("Sorry your account balance is not sufficient to withdraw "+withdrawAmount+ " so enter the amount available in the account");
				}else {
				remainingBalance=(long)(balance-withdrawAmount);
				acc.setBalance(remainingBalance);
		}
		}
		}
//		System.out.println("dffd");
		return remainingBalance;
	}
	public long fundTransfer(long accountNo, long fundAmount) {
		long availableBalance=0;
		Iterator<BankAccount> iterator=accountMap.values().iterator();
		while(iterator.hasNext()) {
			BankAccount acc=iterator.next();
			long accNo=acc.getAccountNo();
			double balance=acc.getBalance();
			//System.out.println("balance is:"+balance);
			if(accNo==accountNo) {
				availableBalance=(long)(balance-fundAmount);
				acc.setBalance(availableBalance);
		}
		}
		
      return availableBalance;
	}
//	@Override
//	public Map<Integer, Transaction> transactionDetails(Transaction transaction) {
//		transactionDetails.put(transaction.getTransactionId(), transaction);
//		return transactionDetails;
//	}

	@Override
	public boolean addAccount(long customerId, BankAccount account) {
		// TODO Auto-generated method stub
		accountMap.put(customerId, account);
		return true;
	}
	public List<Transaction > getTotalTransactions()  {
		List<Transaction> transactions=new ArrayList<Transaction>();
		Collection<Transaction> collection=transactionDetails.values();
		transactions.addAll(collection);
		return transactions;
	}

	@Override
	public Map<Integer, Transaction> transactionDetails(Transaction transaction) {
		transactionDetails.put(transaction.getTransactionId(), transaction);
		return transactionDetails;
	}

	@Override
	public double getBalance(long accountNo) {
		Iterator<BankAccount> iterator1=accountMap.values().iterator();
		double balance=4567L;
		while(iterator1.hasNext())
		{
			BankAccount acc=iterator1.next();
			long accNo=acc.getAccountNo();
			 balance=acc.getBalance();
			if(accNo==accountNo)
			{
				balance=balance;
			}
		}   
	        return balance;
		
		
	}

	@Override
	public BankAccount accountNoCheck(long accountNo) throws BankException {
		boolean accountStatus=false;
		BankAccount account=null;
		Iterator<BankAccount> iterator=accountMap.values().iterator();
		while(iterator.hasNext()) {
			account=iterator.next();
			if(account.getAccountNo()==accountNo) {
				accountStatus=true;
			}
			if(accountStatus==true) {
				break;
			}
		}
		if(accountStatus==false) {
			throw new BankException("Sorry the account number doesnot exist. Please enter your correct account number.");
		}
		return account;
	}



		
	
	}

	


//	@Override
//	public Map<Integer, Transaction> transactionDetails(Transaction transaction) {
//		// TODO Auto-generated method stub
//		return null;
//	}



