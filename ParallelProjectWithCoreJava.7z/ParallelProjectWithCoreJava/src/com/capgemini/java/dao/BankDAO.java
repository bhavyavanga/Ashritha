package com.capgemini.java.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public interface BankDAO {
	
   // long addAccountDetails(BankAccount account);
	long addDeposit(long accountNo, long depositedAmount);
	public Map<Long, BankAccount> accountDetails(BankAccount account);
	
	//public long getBalance(long accountNo);

//	public Map<Integer, BankAccount> getAllAccountDetails();
//	public Map<Integer, Transaction> getAllTransactionDetails();
	boolean addAccount(long customerId, BankAccount account);
	long afterWithdraw(long accountNo, long withdrawAmount);
	 long fundTransfer(long accountNo, long fundAmount);
	 public List<Transaction > getTotalTransactions();
	 int addTransactionDetails(Transaction transaction);
	 public Map<Integer, Transaction> transactionDetails(Transaction transaction);
	 public double getBalance(long accountNo);
	 public BankAccount accountNoCheck(long accountNo) throws BankException;
}
