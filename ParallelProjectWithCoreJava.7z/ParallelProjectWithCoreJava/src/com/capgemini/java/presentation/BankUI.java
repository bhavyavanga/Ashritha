package com.capgemini.java.presentation;


import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;
import com.capgemini.java.service.BankService;
import com.capgemini.java.service.BankServiceImpl;

public class BankUI {

	private static final String Name = null;

	public static void main(String[] args)   {
		String continueChoice;
		boolean continueValue = false;

		 Scanner scanner = null;
		do {

			System.out.println("****** Welcome To The Bank ******");
			System.out.println("1.Create The Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show The Balance");
			System.out.println("6.Print The Transaction");
			System.out.println("7. Exit");
			BankService service=new BankServiceImpl();
			int choice = 0;
			boolean choiceFlag = false;
			do {
				System.out.println("Enter Input:");
				try {
					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					choiceFlag = true;
				    
					switch(choice) {
					case 1:{
						String firstName=null;
						String surName=null; 
						long mobile=0;
						System.out.println("***Creating The Account***");
						boolean fnameFlag=false;
						do {
					System.out.println("Enter your first Name:");
					scanner = new Scanner(System.in);
				    firstName=scanner.next();
				    fnameFlag=true;
				    if(!service.isNameValid(firstName)) {
				    	try {
							throw new BankException("The Name should start with capital letter and name should be minimum of 5 characters");
						} catch (BankException e) {
							fnameFlag=false;
							System.out.println(e.getMessage());
						}
				    }
						}while(!fnameFlag);
						
						
						
						boolean sNameFlag=false;
						do {
					System.out.println("Enter your Surname:");
					scanner = new Scanner(System.in);
				    surName=scanner.next();
				    sNameFlag=true;
				    if(!service.isNameValid(surName)) {
				    	try {
							throw new BankException("The Name should start with capital letter and name should be minimum of 5 characters");
						} catch (BankException e) {
							sNameFlag=false;
							System.out.println(e.getMessage());
						}
				    }
						}while(!sNameFlag);
						
						
						boolean phoneFlag=false;
						do {
				    System.out.println("Enter the Mobile number:");
				    scanner = new Scanner(System.in);
				     mobile=scanner.nextLong();
				    phoneFlag=true;
				    if(!service.isPhoneValid(mobile)) {
				    	try {
							throw new BankException("The mobile number should start with 7,8 or 9 and should have only 10 digits and not caharacters");
						} catch (BankException e) {
							phoneFlag=false;
							System.out.println(e.getMessage());
						}
				    }
						}while(!phoneFlag);
						 double balance=0;
						 boolean balFlag=false;
						 do {
				    System.out.println("Enter the balance:");
				    scanner = new Scanner(System.in);
				   balance=scanner.nextDouble();
				   balFlag=true;
				   
				   try {
					service.isBalanceValid(balance);
					
				} catch (BankException e) {
					balFlag=false;
					System.out.println(e.getMessage());
				}
				    }while(!balFlag);
				  
				    	
				    
				 
					System.out.println("enter the gender:");
					scanner = new Scanner(System.in);
					String gender=scanner.next();
					//BankAccount account=new BankAccount(0, balance, name, mobile);
                 long customerId=service.addAccountDetails();
                /* BankAccount account=new BankAccount(customerId, balance, name, mobile);*/
                 BankAccount account=new BankAccount(customerId, balance, firstName, surName, mobile);
                 service.addAccount(customerId,account);
                 System.out.println("Account created successfully with Id number:"+customerId);
					}break;
					case 2:
					{
						long accountNo=0;
						System.out.println("***Depositing***");
						/*boolean accountFlag=false;
						do {*/
						System.out.println("Enter your Account Number:");
						scanner = new Scanner(System.in);
						 accountNo=scanner.nextLong();
						/* try {
							service.accountNoCheck(accountNo);
						} catch (BankException e) {
							
							e.printStackTrace();
						}*/
//						accountFlag=true;
						/*try {
							if(!service.validateAccountNo(accountNo)) {
								try {
									throw new BankException("Account Number is not valid");
								} catch (BankException e) {
									accountFlag=false;
									System.out.println(e.getMessage());
								}
							}
						} catch (BankException e) {
							
							e.printStackTrace();
						}*/
						/*}while(!accountFlag);*/
						System.out.println("Enter the amount to be deposited");
						scanner = new Scanner(System.in);
						int depositedAmount=scanner.nextInt();
						long deposit=service.addDeposit(accountNo, depositedAmount);
						System.out.println("The remaining balance in the acccount after deposit of" +depositedAmount+ " is "+deposit);
						Date transactionDate=new Date();
						Transaction transaction=new Transaction(0, transactionDate, accountNo, deposit);
						int transcationId=service.addTransactionDetails(transaction);
						
					}break;
					case 3:{
						System.out.println("***Withdrawing***");
						System.out.println("Enter the account number");
						scanner = new Scanner(System.in);
						long accountNo=scanner.nextLong();
						System.out.println("Enter the Amount to be withdrawn:");
						scanner = new Scanner(System.in);
						long withdrawAmount=scanner.nextLong();
						long balance=service.afterWithdraw(accountNo, withdrawAmount);
					    System.out.println("The balance after withdrawing  is " +balance);
					    Date transactionDate=new Date();
						Transaction transaction=new Transaction(0, transactionDate, accountNo, withdrawAmount);
						int transcationId=service.addTransactionDetails(transaction);
		
					}break;
					case 4:{
						System.out.println("***Fund Transfer***");
						System.out.println("Enter Your accountNo:");
						scanner = new Scanner(System.in);
						long accountNo=scanner.nextLong();
						System.out.println("Enter the account Number To which the amount is to be sent:");
						scanner = new Scanner(System.in);
						long account=scanner.nextLong();
						System.out.println("Enter the amount to be sent:");
						scanner = new Scanner(System.in);
						long fundAmount=scanner.nextLong();
						long balanceLeft=service.fundTransfer(accountNo, fundAmount);
						System.out.println("The remaining balance After The Fund Transfer is:"+balanceLeft);
						Date transactionDate=new Date();
						Transaction transaction=new Transaction(0, transactionDate, accountNo, fundAmount);
						int transcationId=service.addTransactionDetails(transaction);
						
					}break;
					case 5:{
						scanner = new Scanner(System.in);
						System.out.println("Enter your account number:");
						scanner = new Scanner(System.in);
							long accountNo=scanner.nextLong();
							double bal=service.getBalance(accountNo);
							  System.out.println("Your account balance is:"+bal);
			
						
					}break;
					
					case 6:
					{
						System.out.println("***Transaction Details***");
						System.out.println("Enter the account No:");
						scanner = new Scanner(System.in);
						long accountNo=scanner.nextLong();
					    List<Transaction> transactionList=new ArrayList<>();
					   
					    System.out.println(service.getTotalTransactions());
						
						
					}break;
					case 7:{
						System.out.println("Thank you");
						System.exit(0);
					}break;
					}
	} catch (InputMismatchException exception) {
		choiceFlag = false;
		System.err.println("input should contain only digits");
	}
} while (!choiceFlag);

		do {
			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();
			if (continueChoice.equalsIgnoreCase("yes")) {
				continueValue = true;
				break;
			} else if (continueChoice.equalsIgnoreCase("no")) {
				System.out.println("thank you");
				continueValue = false;
				break;
			} else {
				System.out.println("enter yes or no");
				continueValue = false;
				continue;
			}
		} while (!continueValue);

	} while (continueValue);
	scanner.close();
}
	}


