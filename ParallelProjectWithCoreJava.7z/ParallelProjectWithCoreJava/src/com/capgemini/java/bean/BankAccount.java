package com.capgemini.java.bean;

public class BankAccount {

	private long accountNo;
	private double balance;
	private String firstName;
	private String surName;
	private long mobileNumber;
	/*public BankAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankAccount(long accountNo, double balance, String customerName, long mobileNumber) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.customerName = customerName;
		this.mobileNumber = mobileNumber;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", balance=" + balance + ", customerName=" + customerName
				+ ", mobileNumber=" + mobileNumber + "]";
	}
	
	*/
	public BankAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankAccount(long accountNo, double balance, String firstName, String surName, long mobileNumber) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.firstName = firstName;
		this.surName = surName;
		this.mobileNumber = mobileNumber;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", balance=" + balance + ", firstName=" + firstName
				+ ", surName=" + surName + ", mobileNumber=" + mobileNumber + "]";
	}
	
	
}
