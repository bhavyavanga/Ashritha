package com.capgemini.java.service;

import java.util.List;
import java.util.Map;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.exception.BankException;

public interface BankService {

	long addAccountDetails();
//	int addTransactionDetails(Transaction transaction);
//	public Map<Integer, BankAccount> getAllAccountDetails();
//	public Map<Integer, Transaction> getAllTransactionDetails();
	long addDeposit(long accountNo, long depositedAmount);
	boolean addAccount(long customerId, BankAccount account);
	long afterWithdraw(long accountNo, long withdrawAmount);
	public long fundTransfer(long accountNo, long fundAmount);
	public List<Transaction > getTotalTransactions();
	 public int addTransactionDetails(Transaction transaction);
	 public boolean isNameValid(String name);
	 public boolean isPhoneValid(long phone);
	 public boolean validateAccountNo(long accountNo) throws BankException;
	 public double getBalance(long accountNo);
	 public boolean isBalanceValid(double balance) throws BankException;
	public BankAccount accountNoCheck(long accountNo) throws BankException;

}
