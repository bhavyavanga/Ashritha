package com.capgemini.java.service;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.java.bean.BankAccount;
import com.capgemini.java.bean.Transaction;
import com.capgemini.java.dao.BankDAO;
import com.capgemini.java.dao.BankDaoImpl;
import com.capgemini.java.exception.BankException;

public class BankServiceImpl implements BankService {
       BankDAO dao=new BankDaoImpl();
	@Override
	public long addAccountDetails() {
		long accountNo=(long)(Math.random()*100000000);

		return accountNo;
	}

//	@Override
//	public int addTransactionDetails(Transaction transaction) {
//		
//		return dao.addTransactionDetails(transaction);
//	}

//	@Override
//	public Map<Integer, BankAccount> getAllAccountDetails() {
//		
//		return null;
//	}
//
//	@Override
//	public Map<Integer, Transaction> getAllTransactionDetails() {
//		
//		return null;
//	}

	@Override
	public boolean isNameValid(String name) {
		Pattern nameptn=Pattern.compile("^[A-Z]{1}[a-z]{4,}$");
		Matcher match=nameptn.matcher(name);
		if(match.matches()) {
			return true;
		}
		return false;
		
	}
	@Override
	public boolean isPhoneValid(long phone) {
		String mobile=String.valueOf(phone);
		Pattern mobileptn=Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher match=mobileptn.matcher(mobile);
		if(match.matches()) {
			return true;
		}
		return false;
		
	}
	
	@Override
	public boolean isBalanceValid(double balance) throws BankException{
		boolean balanceFlag=false;
		if(balance<1000) {
			throw new BankException("Sorry, the minimum balance in the account should be 1000 and not less than that");
		}else {
			balanceFlag=true;
		}
		return balanceFlag;
	}

 /*public boolean validateAccountNo(String account) throws BankException{
	
	String account1=String.valueOf(account);
	Pattern accountptn=Pattern.compile("^[7-9]{1}[0-9]{9}$");
	Matcher match=accountptn.matcher(account1);
	if(match.matches()) {
		return true;
	}
	return false;
	
}*/

@Override
public long addDeposit(long accountNo, long depositedAmount) {
	
	return dao.addDeposit(accountNo, depositedAmount);
}
	public Map<Long, BankAccount> accountDetails(BankAccount account){
		return dao.accountDetails(account);
	}

	@Override
	public boolean addAccount(long customerId, BankAccount account) {
		// TODO Auto-generated method stub
		return dao.addAccount(customerId,account);
	}

	@Override
	public long afterWithdraw(long accountNo, long withdrawAmount) {
		
		return dao.afterWithdraw(accountNo, withdrawAmount);
	}
	public long fundTransfer(long accountNo, long fundAmount) {
		return dao.fundTransfer(accountNo, fundAmount);
	}

	public int addTransactionDetails(Transaction transaction) {
        int id=(int)(Math.random()*1000);
        transaction.setTransactionId(id);
        return dao.addTransactionDetails(transaction);
    }
//	public int addTransaction(){
//		return dao.addTransactionDetails(transaction);
//	}
	@Override
	public List<Transaction> getTotalTransactions() {
		
		return dao.getTotalTransactions();
	}

	@Override
	public boolean validateAccountNo(long accountNo) throws BankException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double getBalance(long accountNo) {
		// TODO Auto-generated method stub
		return dao.getBalance(accountNo);
	}

	@Override
	public BankAccount accountNoCheck(long accountNo) throws BankException {
		
		return dao.accountNoCheck(accountNo);
	}
	
}
