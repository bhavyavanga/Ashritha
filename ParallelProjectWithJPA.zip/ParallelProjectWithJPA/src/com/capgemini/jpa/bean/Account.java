package com.capgemini.jpa.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Account {
	@Id
	
	@SequenceGenerator(name="seq",sequenceName = "accbankseq",allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "seq") 
	private long accountNo;
    private String firstName;
    private String surName;
	private long mobileNumber;
	private String gender;
	private long balance;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long accountNo, String firstName, String surName, long mobileNumber, String gender, long balance) {
		super();
		this.accountNo = accountNo;
		this.firstName = firstName;
		this.surName = surName;
		this.mobileNumber = mobileNumber;
		this.gender = gender;
		this.balance = balance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getSurName() {
		return surName;
	}
	public void setSurName(String surName) {
		this.surName = surName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", firstName=" + firstName + ", surName=" + surName
				+ ", mobileNumber=" + mobileNumber + ", gender=" + gender + ", balance=" + balance + "]";
	}
	
	

}
