package com.capgemini.jpa.presentation;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.capgemini.jpa.bean.Account;
import com.capgemini.jpa.exception.BankException;
import com.capgemini.jpa.service.BankService;
import com.capgemini.jpa.service.BankServiceImpl;

public class MainUI {
	 static BankService service=new BankServiceImpl();
	 static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) throws BankException {
		
		String continueChoice;
		boolean continueValue = false;

		
		do {

			System.out.println("****** Welcome To The Bank ******");
			System.out.println("1.Create The Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.Fund Transfer");
			System.out.println("5.Show The Balance");
			System.out.println("6.Print The Transaction");
			System.out.println("7. Exit");
			
			int choice = 0;
			boolean choiceFlag = false;
			do {
				System.out.println("Enter Input:");
				try {
//					scanner = new Scanner(System.in);
					choice = scanner.nextInt();
					choiceFlag = true;
					switch(choice) {
					case 1:{
						String firstName=null;
						String surName=null;
						long mobile=0;
						long balance=0;
						System.out.println("***Creating The Account***");
						boolean fNameFlag=false;
						do {
						System.out.println("Enter your first name:");
						
//						scanner=new Scanner(System.in);
						firstName=scanner.next();
						 fNameFlag=true;
						    if(!service.isNameValid(firstName)) {
						    	try {
									throw new BankException("The Name should start with capital letter and name should be minimum of 5 characters");
								} catch (BankException e) {
									fNameFlag=false;
									System.out.println(e.getMessage());
								}
						    }
								}while(!fNameFlag);
								
						boolean sNameFlag=false;
						do {
						System.out.println("Enter your sur name:");
//						scanner=new Scanner(System.in);
						 surName=scanner.next();
						 sNameFlag=true;
						    if(!service.isNameValid(surName)) {
						    	try {
									throw new BankException("The Name should start with capital letter and name should be minimum of 5 characters");
								} catch (BankException e) {
									sNameFlag=false;
									System.out.println(e.getMessage());
								}
						    }
						}while(!sNameFlag);
						boolean mobileFlag=false;
						do {
						System.out.println("Enter your mobile number:");
//				        scanner=new Scanner(System.in);
				         mobile=scanner.nextLong();
				         mobileFlag=true;
						    if(!service.isPhoneValid(mobile)) {
						    	try {
									throw new BankException("The mobile number should start with 7,8 or 9 and should have only 10 digits and not caharacters");
								} catch (BankException e) {
									mobileFlag=false;
									System.out.println(e.getMessage());
								}
						    }
						}while(!mobileFlag);
				        System.out.println("Enter your gender:");
//				        scanner=new Scanner(System.in);
				        String gender=scanner.next();
				        boolean balFlag=false;
				        do {
				        System.out.println("Enter the balance:");
//				        scanner=new Scanner(System.in);
				        balance=scanner.nextLong();
				        balFlag=true;
						   
						   try {
							service.isBalanceValid(balance);
							
						} catch (BankException e) {
							balFlag=false;
							System.out.println(e.getMessage());
						}
				        }while(!balFlag);
				        Account account=new Account(0, firstName, surName, mobile, gender, balance);
				        long accountNo=service.addAccountDetails(account);
				        System.out.println("Your account is created successfully with account number "+accountNo);
						
						
					}break;
					case 2:{
						System.out.println("Enter your account no:");
//						scanner=new Scanner(System.in);
						long accountNo=scanner.nextLong();
						System.out.println("Enter the amount to be deposited:");
//						scanner=new Scanner(System.in);
						long depositAmount=scanner.nextLong();
						long deposit=service.addDeposit(accountNo, depositAmount);
						System.out.println("Amount deposited successfully and the total balance in account after deposit of "+depositAmount+" is "+deposit);
					}break;
					case 3:{
						System.out.println("Enter your account no:");
//						scanner=new Scanner(System.in);
						long accountNo=scanner.nextLong();
						System.out.println("Enter amount to be withdrawn:");
						long withdrawAmount=scanner.nextLong();
						long balance=service.afterWithdraw(accountNo, withdrawAmount);
						System.out.println("Amount withdrawn successfully and the remaining balance in account after withdraw of "+withdrawAmount+" is "+balance);
					}break;
					
					case 4:{
						System.out.println("Enter your account no:");
						long accountNo=scanner.nextLong();
						System.out.println("Enter the account number to which the amount is to transferred:");
						long fundAccount=scanner.nextLong();
						System.out.println("Enter the amount to be transferred:");
						long fundAmount=scanner.nextLong();
						long balance=service.fundTransfer(accountNo, fundAmount);
						System.out.println("Amount transferred sucessfully to account "+fundAccount+" and remaining balance in your account after fund transfer of "+fundAmount+" is "+balance );
						
					}break;
					
					case 5:{
						System.out.println("Enter account no:");
						long accountNo=scanner.nextLong();
						long balance=service.showBalance(accountNo);
						System.out.println("The available balance in your account is "+balance);
					}break;
					case 7:{
						System.out.println("Thank you");
						System.exit(0);
					}break;
					}
	} catch (InputMismatchException exception) {
		choiceFlag = false;
		System.err.println("input should contain only digits");
	}
} while (!choiceFlag);

		do {
			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();
			if (continueChoice.equalsIgnoreCase("yes")) {
				continueValue = true;
				break;
			} else if (continueChoice.equalsIgnoreCase("no")) {
				System.out.println("thank you");
				continueValue = false;
				break;
			} else {
				System.out.println("enter yes or no");
				continueValue = false;
				continue;
			}
		} while (!continueValue);

	} while (continueValue);
	scanner.close();
}
	



	}


